from .Lexer import Lexer
from .Grammar import Grammar

class Parser:
    """
    Combines lexical analysis (Lexer) and syntax analysis (Grammar/CYK).
    Converts input text -> tokens -> parse tree.
    """

    def __init__(self, lexer: Lexer, grammar: Grammar) -> None:
        """
        Initialize parser with lexer and grammar.
        lexer: Tokenizes input into (token_type, lexeme) pairs
        grammar: CNF grammar for syntax analysis using CYK algorithm
        """
        self.lexer = lexer
        self.grammar = grammar

    def parse(self, input_text: str):
        """
        Parse input text and return parse tree as string or error message.
        
        Process:
        1. Lexical analysis: text -> tokens
        2. Filter whitespace tokens
        3. Syntax analysis: tokens -> parse tree
        4. Return formatted parse tree or error
        """
        
        # --- STEP 1: Lexical Analysis ---
        # Convert input text to list of (token_type, lexeme) pairs
        tokens = self.lexer.lex(input_text)

        # Check if lexer found an error
        # Lexer errors are returned as [("", "error message")]
        if tokens and tokens[0][0] == "":
            return tokens[0][1]  # Return error message string

        # --- STEP 2: Filter Whitespace ---
        # Remove SPACE tokens (not needed for syntax analysis)
        filtered_tokens = [token for token in tokens if token[0] != "SPACE"]

        # --- STEP 3: Syntax Analysis (CYK Algorithm) ---
        # Use grammar to parse filtered tokens into parse tree
        parse_tree = self.grammar.cykParse(filtered_tokens)

        # --- STEP 4: Return Result ---
        if parse_tree:
            # Successfully parsed: return formatted parse tree
            return str(parse_tree)
        
        # Parsing failed: input doesn't match grammar
        return "Syntax Error"