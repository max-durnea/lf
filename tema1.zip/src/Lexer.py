from .Regex import Regex, parse_regex
from .NFA import NFA, EPSILON

class Lexer:
    def __init__(self, spec: list[tuple[str, str]]) -> None:
        """
        Initialize lexer with token specifications.
        spec: list of (token_name, regex_string) pairs
        """
        self.spec = spec
        
        # Convert each regex to NFA, then to DFA
        self.token_dfas = []
        for token_name, regex_string in spec:
            # Parse regex string -> Regex object -> NFA -> DFA
            regex = parse_regex(regex_string)
            nfa = regex.thompson()
            dfa = nfa.subset_construction()
            self.token_dfas.append((token_name, dfa))
    
    def lex(self, word: str) -> list[tuple[str, str]]:
        """
        Tokenize input string using longest match principle.
        Returns list of (token_name, lexeme) pairs or error message.
        """
        tokens = []
        position = 0
        input_length = len(word)
        
        # --- Main tokenization loop ---
        while position < input_length:
            # Find the longest matching token starting at current position
            longest_match_end = position
            longest_match_token = None
            longest_match_index = None

            # Try each token's DFA to find longest match
            for token_index, (token_name, dfa) in enumerate(self.token_dfas):
                current_state = dfa.q0
                current_pos = position
                last_accepting_pos = None
                
                # Check if initial state is accepting (matches empty string)
                if current_state in dfa.F:
                    last_accepting_pos = current_pos

                # Follow DFA transitions as far as possible
                while current_pos < input_length:
                    char = word[current_pos]
                    
                    # Check if transition exists
                    if (current_state, char) not in dfa.d:
                        break  # DFA stuck, can't continue
                    
                    # Take transition
                    current_state = dfa.d[(current_state, char)]
                    current_pos += 1
                    
                    # Check if new state is accepting
                    if current_state in dfa.F:
                        last_accepting_pos = current_pos
                
                # Update longest match if this token matched longer
                if last_accepting_pos is not None:
                    if last_accepting_pos > longest_match_end:
                        longest_match_end = last_accepting_pos
                        longest_match_token = token_name
                        longest_match_index = token_index
                    # Tie-break: prefer earlier token in specification
                    elif last_accepting_pos == longest_match_end:
                        if longest_match_token is not None and token_index < longest_match_index:
                            longest_match_token = token_name
                            longest_match_index = token_index

            # --- Handle no match (lexical error) ---
            if longest_match_token is None or longest_match_end == position:
                error_position = self._find_error_position(word, position, input_length)
                error_message = self._format_error_message(word, error_position, input_length)
                return [("", error_message)]

            # --- Add matched token to result ---
            lexeme = word[position:longest_match_end]
            tokens.append((longest_match_token, lexeme))
            position = longest_match_end

        return tokens

    def _find_error_position(self, word: str, position: int, input_length: int) -> int:
        """
        Find the position where lexical error occurred.
        Returns the earliest position where all DFAs got stuck.
        """
        earliest_stuck_position = None

        # Try each DFA to see where it gets stuck
        for token_name, dfa in self.token_dfas:
            current_state = dfa.q0
            current_pos = position

            # Try to make at least one transition
            if current_pos < input_length and (current_state, word[current_pos]) in dfa.d:
                # Follow DFA until it gets stuck
                while current_pos < input_length and (current_state, word[current_pos]) in dfa.d:
                    current_state = dfa.d[(current_state, word[current_pos])]
                    current_pos += 1
                
                # Track earliest stuck position
                if earliest_stuck_position is None or current_pos < earliest_stuck_position:
                    earliest_stuck_position = current_pos

        # If no DFA could start, error is at current position
        if earliest_stuck_position is None:
            return position
        
        # If DFA consumed multiple characters before getting stuck,
        # report error at previous character
        if (earliest_stuck_position - position) > 1:
            return earliest_stuck_position - 1
        else:
            return earliest_stuck_position

    def _format_error_message(self, word: str, error_position: int, input_length: int) -> str:
        """
        Format lexical error message with line and column information.
        """
        # Count lines up to error position (0-indexed)
        line_number = word[:error_position].count('\n')
        
        # Check if error is at end of file
        if error_position >= input_length:
            return f"No viable alternative at character EOF, line {line_number}"
        
        # Calculate column (position within current line)
        last_newline_pos = word.rfind('\n', 0, error_position)
        column_number = error_position - (last_newline_pos + 1)
        
        return f"No viable alternative at character {column_number}, line {line_number}"