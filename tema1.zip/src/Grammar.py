from .ParseTree import ParseTree

EPSILON = ""

class Grammar:
    @classmethod
    def fromFile(cls, file_name: str):
        """Load grammar from file in format: lhs: rhs1 rhs2|alternative"""
        with open(file_name, 'r') as f:
            V = set()  # Set of all symbols (terminals + non-terminals)
            R = set()  # Set of production rules
            S = None   # Start symbol (first non-terminal found)
            
            for line in f:
                line = line.strip()
                if not line or ":" not in line:
                    continue

                # Split line into left side and right side
                lhs, rhs = line.split(":", 1)
                non_terminal = lhs.strip()
                V.add(non_terminal)
                
                # First non-terminal becomes start symbol
                if not S:
                    S = non_terminal

                # Handle alternatives separated by |
                alternatives = rhs.split("|")
                for alt in alternatives:
                    alt = alt.strip()
                    symbols = alt.split()  # Split by whitespace
                    
                    # Binary rule: A -> B C
                    if len(symbols) == 2:
                        symbol1, symbol2 = symbols
                        V.add(symbol1)
                        V.add(symbol2)
                        R.add((non_terminal, symbol1, symbol2))
                    
                    # Unit rule: A -> B or A -> epsilon
                    elif len(symbols) == 1:
                        symbol = symbols[0]
                        if symbol == EPSILON:
                            R.add((non_terminal, EPSILON, None))
                        else:
                            V.add(symbol)
                            R.add((non_terminal, symbol, None))
                    
                    # Empty production (epsilon)
                    elif len(symbols) == 0 and alt == EPSILON:
                        R.add((non_terminal, EPSILON, None))

        return cls(V, R, S)

    def __init__(self, V: set[str], R: set[tuple[str, str, str|None]], S: str):
        self.V = V  # Vocabulary (all symbols)
        self.R = R  # Rules (production rules)
        self.S = S  # Start symbol

    def cykParse(self, tokens: list[tuple[str, str]]):
        """
        CYK Algorithm for parsing tokens using CNF grammar.
        Returns ParseTree if tokens are accepted, None otherwise.
        
        tokens: list of (token_type, lexeme) pairs from lexer
        """
        n = len(tokens)
        
        # Create DP table: table[i][j] = dict of {non_terminal: ParseTree}
        # table[i][j] represents substring from position i to j (1-indexed)
        table = [[dict() for _ in range(n + 1)] for _ in range(n + 1)]

        # Special case: empty input
        if n == 0:
            # Check if S -> epsilon exists
            for (A, B, C) in self.R:
                if A == self.S and B == EPSILON and C is None:
                    return ParseTree(self.S)
            return None

        # --- Helper function: Apply unit productions ---
        def apply_unit_productions(cell):
            """
            Apply unit productions (A -> B where B is non-terminal).
            Keep applying until no new non-terminals can be added.
            """
            changed = True
            while changed:
                changed = False
                # Try every unit production A -> B
                for (A, B, C) in self.R:
                    if C is None and B != EPSILON:  # Unit production
                        if B in cell and A not in cell:
                            # Create parse tree: A derives B
                            tree = ParseTree(A)
                            tree.add_children(cell[B])
                            cell[A] = tree
                            changed = True

        # --- STEP 1: Fill base case (substrings of length 1) ---
        for i in range(1, n + 1):
            token_type, lexeme = tokens[i - 1]
            
            # Add the token itself as a leaf node
            table[i][i][token_type] = ParseTree(token_type, token=(token_type, lexeme))
            
            # Apply terminal productions: A -> token_type
            for (A, B, C) in self.R:
                if C is None and B == token_type:  # Terminal production
                    if A not in table[i][i]:
                        tree = ParseTree(A)
                        tree.add_children(ParseTree(token_type, token=(token_type, lexeme)))
                        table[i][i][A] = tree
            
            # Apply unit productions to this cell
            apply_unit_productions(table[i][i])

        # --- STEP 2: Fill table for substrings of increasing length ---
        for length in range(2, n + 1):  # Substring length
            for start in range(1, n - length + 2):  # Start position
                end = start + length - 1  # End position
                
                # Try all ways to split substring [start, end]
                for split in range(start, end):  # Split position
                    # Try all binary rules: A -> B C
                    for (A, B, C) in self.R:
                        if C is not None:  # Binary rule
                            # Check if B derives left part and C derives right part
                            left_part = table[start][split]
                            right_part = table[split + 1][end]
                            
                            if B in left_part and C in right_part:
                                if A not in table[start][end]:
                                    # Create parse tree: A derives B C
                                    tree = ParseTree(A)
                                    tree.add_children(left_part[B])
                                    tree.add_children(right_part[C])
                                    table[start][end][A] = tree
                
                # Apply unit productions after all binary rules
                apply_unit_productions(table[start][end])

        # --- STEP 3: Check if start symbol can derive entire input ---
        if self.S in table[1][n]:
            return table[1][n][self.S]
        
        return None  # Input not accepted by grammar