from __future__ import annotations

class ParseTree:
    """
    Represents a node in a parse tree.
    Can be either a terminal node (has token) or non-terminal node (has children).
    """

    def __init__(self, name: str, token: tuple[str, str] = None):
        """
        Initialize a parse tree node.
        name: Non-terminal name or token type
        token: Optional (token_type, lexeme) pair for terminal nodes
        """
        self.name = name
        self.children = []
        self.token = token  # If set, this is a terminal/leaf node

    def add_children(self, child: ParseTree):
        """Add a child node to this node."""
        self.children.append(child)
    
    def to_string(self, indent_level=0):
        """
        Convert parse tree to formatted string representation.
        indent_level: Current indentation level (0 = root)
        """
        # Calculate indentation (2 spaces per level)
        indentation = "  " * indent_level
        
        # --- Case 1: Terminal node (leaf) ---
        if self.token:
            token_type, lexeme = self.token
            return f"{indentation}({token_type}: {lexeme})"
        
        # --- Case 2: Non-terminal node ---
        
        # Special case: Flatten wrapper nodes with single terminal child
        # (e.g., if node just wraps a terminal, show the terminal directly)
        if len(self.children) == 1 and self.children[0].token is not None:
            return self.children[0].to_string(indent_level)
        
        # Special case: Intermediate nodes (int_*) are invisible
        # Only show their children without the node name
        if self.name.startswith("int_"):
            result = ""
            for child in self.children:
                result += "\n" + child.to_string(indent_level)
            # Remove leading newline
            return result[1:]
        
        # Regular case: Show node name and all children (indented)
        result = f"{indentation}{self.name}"
        for child in self.children:
            result += "\n" + child.to_string(indent_level + 1)
        
        return result

    def __str__(self):
        """String representation of the parse tree."""
        return self.to_string()