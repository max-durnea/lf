from typing import Any, List
from .NFA import NFA

EPSILON = ''



class Regex:
    def thompson(self) -> NFA[int]:
        pass
    
def parse_regex(s: str) -> Regex:
    pass
        