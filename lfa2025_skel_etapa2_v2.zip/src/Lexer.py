from .Regex import Regex, parse_regex
from .NFA import NFA, EPSILON
from functools import reduce

class Lexer:
    def __init__(self, spec: list[tuple[str, str]]) -> None:
        pass
    
    def lex(self, word: str) -> list[tuple[str, str]]:
        pass
